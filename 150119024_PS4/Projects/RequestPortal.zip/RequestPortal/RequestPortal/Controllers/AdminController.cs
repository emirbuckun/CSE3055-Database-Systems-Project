﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using RequestPortal.Models;

namespace RequestPortal.Controllers;

public class AdminController : Controller
{
    private readonly ILogger<AdminController> _logger;

    public AdminController(ILogger<AdminController> logger)
    {
        _logger = logger;
    }

    public new IActionResult Request()
    {
        return View();
    }

    public IActionResult Employee()
    {
        return View();
    }

    public IActionResult City()
    {
        return View();
    }

    public IActionResult Company()
    {
        return View();
    }

    public IActionResult Department()
    {
        return View();
    }

    public new IActionResult User()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

