﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using RequestPortal.Models;
using RequestPortal.RequestPortalDB;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace RequestPortal.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public ActionResult MyRequests()
    {
        return View();
    }

    public IActionResult WaitingRequests()
    {
        return View();
    }

    public IActionResult ProcessedRequests()
    {
        return View();
    }

    public IActionResult CreateRequest()
    {
        return View();
    }

    public IActionResult RequestDetails()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

